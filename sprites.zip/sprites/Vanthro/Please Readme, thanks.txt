I'm including this folder so that you know what basic sprites are needed. 
- Portrait
- Menu button
- Map Icon
- Sit 1
- Sit 2
- Ultra Button(s)
- Ultra HUD Icon(s)